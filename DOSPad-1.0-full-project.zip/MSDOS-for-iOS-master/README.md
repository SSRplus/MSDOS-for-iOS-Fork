# DOSPad 1.0

DOS + Windows 95/98 emulator for iPhone / iPad (**iOS 14+, arm64**), based on DOSBox 0.74 and SDL 1.3.
เวอร์ชัน 1.0 — ปรับ UI ใหม่ทั้งหมด, นำเข้าเกม/ดิสก์อิมเมจ, คีย์บอร์ด PC ในตัว, เมาส์ทัชสกรีน, รองรับ TrollStore / SideStore / AltStore / StikDebug / LiveContainer, build IPA ด้วย GitHub Actions

## มีอะไรใหม่ใน 1.0

| หมวด | รายละเอียด |
|---|---|
| UI | หน้า Launcher แบบการ์ด (Windows 95/98 / เกม DOS / DOS Prompt), ธีมมืด, แถบควบคุมเล็กๆ มุมขวาบนที่ซ่อนตัวเอง (ไม่รกจอ), รองรับ notch / Dynamic Island / iPad |
| นำเข้า | ＋ → `.zip`, โฟลเดอร์, `.exe/.com/.bat`, disk image `.img .vhd .ima .iso`, หรือคัดลอกผ่านแอป Files |
| เมาส์ทัช | โหมด **ลาก** (trackpad) และโหมด **แตะ** (direct) — แตะ = คลิกซ้าย, แตะสองนิ้ว = คลิกขวา, แตะแล้วลาก / กดค้าง = drag & drop, ปุ่ม L / R / Hold ลอยบนจอ |
| คีย์บอร์ด | คีย์บอร์ด PC เต็มรูปแบบ 3 หน้า (ABC, F-keys/Nav, Numpad), Shift/Ctrl/Alt/Win แบบ sticky (แตะ = ครั้งเดียว, แตะสองที = ล็อก), ปรับความโปร่งใสได้ + รองรับคีย์บอร์ดฮาร์ดแวร์ |
| Windows 9x | รัน HDD image ของ Win95/98 (`boot -l c`), อ่าน geometry จาก MBR อัตโนมัติ, สร้าง HDD ว่าง 256 MB–2 GB, HDD ตัวที่สอง + Floppy สำหรับติดตั้ง |
| JIT | ตรวจจับ JIT จริง, ขอเปิดผ่าน StikDebug (+ Local Dev VPN) / SideStore / AltStore / TrollStore (self-attach) / LiveContainer, ไม่มี JIT ก็เล่นได้ (Interpreter) — ดู "สถานะ JIT" ด้านล่าง |
| Build | `.github/workflows/build-ipa-from-zip.yml` → IPA 2 แบบ: sideload (ไม่เซ็น) และ TrollStore (fake-sign + entitlements) |
| แก้บั๊กเก่า | แตก zip ผิดพลาด (`/HACKDIR`) + zip-slip, ลิงก์ `libstdc++/libc` ที่ไม่มีใน SDK ใหม่, `NSLog` format, ลูปคัดลอกไฟล์ที่ไม่ทำงาน, ไอคอน/Launch screen สำหรับจอใหม่ |

## สถานะ JIT (อ่านก่อน)

- **ระบบเปิด JIT ครบ**: ตรวจจับจริง (รันโค้ดทดสอบ), ปุ่มขอเปิดผ่าน StikDebug (+ Local Dev VPN) / SideStore / AltStore / TrollStore (self-attach) / LiveContainer, entitlements, ตัวจัดสรร RWX (`dp_jit_alloc`, `dp_jit_write_begin/end`)
- **ARM64 dynamic recompiler backend เขียนแล้ว**: `dosbox/src/cpu/core_dynrec/risc_arm64.h` (เปิดใช้ใน `dosbox/config.h` เฉพาะเครื่องจริง arm64) เลือกใช้ที่ ตั้งค่า → CPU core → *JIT / Dynamic (ทดลอง)*
- ค่าเริ่มต้นยังเป็น Interpreter: backend ผ่านการทดสอบ **นอกเครื่อง** เท่านั้น (ตรวจ encoding ของทุกคำสั่ง + รันบล็อกที่สร้างใน emulator ARM64 จิ๋ว — ดู `tools/jit-tests/`) ยังไม่เคยรันบน iPhone/iPad จริง ถ้าเกมค้าง/เพี้ยนให้สลับกลับเป็น Interpreter
- ถ้าเลือก JIT แต่ JIT ไม่เปิด DOSBox จะ fallback เป็น `normal` เอง (ไม่ crash)

## ใช้งาน

1. ติดตั้ง IPA (ดูด้านล่าง) แล้วเปิดแอป
2. กด ＋ นำเข้าเกม หรือ disk image
3. แตะการ์ดเพื่อเล่น — ในเกมแตะ `•••` มุมขวาบน: คีย์บอร์ด · โหมดเมาส์ · ปุ่มเมาส์ · จอย · ความเร็ว CPU · ภาพหน้าจอ · ตั้งค่า · กลับไลบรารี
4. DOSBox เริ่มได้ครั้งเดียวต่อการเปิดแอป — ถ้าเลือกเกมอื่น แอปจะถามแล้วรีสตาร์ทตัวเองให้ (ถ้าไม่เปิดเอง แตะไอคอนอีกครั้ง)

### Windows 95/98
- **มี image อยู่แล้ว**: นำเข้าไฟล์ `.img/.vhd(fixed)` ต้องเป็น RAW + FAT16/FAT32 (VHD แบบ dynamic / VMDK / QCOW2 ให้แปลงด้วย `qemu-img convert -O raw`)
- **ติดตั้งเอง**: สร้าง HDD ว่าง → แก้ไขรายการ → ใส่ Floppy boot (มี FDISK/FORMAT) และเปิด "บูตจาก Floppy" → FDISK + FORMAT → คัดลอกไฟล์ติดตั้ง Windows ไว้ใน HDD ตัวที่สองแล้วรัน SETUP
- ข้อจำกัดของ DOSBox 0.74: ไม่มีไดรฟ์ CD-ROM ภายใน Windows 9x, ไม่มี driver เครือข่าย/DirectX ฮาร์ดแวร์ — ความเร็วขึ้นกับเครื่อง (Interpreter) ใช้ RAM 32–63 MB และ `cycles=max`

## ติดตั้ง IPA

| วิธี | ไฟล์ | หมายเหตุ |
|---|---|---|
| TrollStore | `DOSPad-1.0-trollstore.ipa` / `.tipa` | เซ็นด้วย `entitlements/TrollStore.entitlements` (JIT, no-sandbox) — ปุ่ม JIT → "TrollStore (self-attach)" |
| SideStore / AltStore / Sideloadly | `DOSPad-1.0-sideload.ipa` | ไม่เซ็น ให้เครื่องมือเซ็นด้วยใบรับรองของคุณ |
| JIT ภายหลัง | StikDebug (เปิด Local Dev VPN / StosVPN), SideStore, AltStore | แอปเรียก `stikjit://`, `sidestore://`, `altstore://enable-jit?bundle-id=com.dospad.app` |
| LiveContainer | ใช้ sideload IPA | เปิดแอปใน LiveContainer ด้วย "Launch with JIT" |

## Build เอง (ทำจากมือถือได้)

1. อัปโหลด `DOSPad-1.0-full-project.zip` ขึ้น repo (Add file → Upload files) — ไม่ต้องแตกไฟล์
2. สร้างไฟล์ `.github/workflows/build-ipa-from-zip.yml` (Add file → Create new file แล้ววางโค้ดจากไฟล์ในชุดนี้)
3. แท็บ **Actions → Build DOSPad IPA (from project zip) → Run workflow** (หรือ push zip ใหม่ มันรันเอง)
4. ได้ `.ipa` / `.tipa` ใน **Artifacts** และหน้า **Releases** (ดาวน์โหลดบนมือถือได้เลย)

workflow แตก zip เอง หา `dospad.xcodeproj` เอง และถ้าไม่มี zip แต่มีไฟล์โปรเจกต์ใน repo ก็ build จากไฟล์นั้นได้
ในเครื่อง: `python3 tools/patch_pbxproj.py` (ไม่ทำอะไรถ้า patch แล้ว) แล้วใช้คำสั่ง `xcodebuild` ตามใน workflow

## โครงสร้างโค้ดใหม่ (`dospad/Modern/`)

`DPLauncherViewController` (ไลบรารี) · `DPPlayViewController` (หน้าเล่น + HUD + จอย) · `DPTouchSurfaceView` (เมาส์ทัช) · `DPPCKeyboardView` (คีย์บอร์ด) · `DPLibrary` (สแกน/นำเข้า/สร้าง config DOSBox) · `DPDiskImage` (MBR/geometry/สร้างอิมเมจ) · `DPJIT` · `DPSettings` · `DPSettingsViewController` · `DPEntryEditorViewController` · `DPTheme`

เกม DOS จะถูก mount โฟลเดอร์เกมเป็นไดรฟ์ `C:`; config ถูกสร้างใหม่ทุกครั้งและส่งให้ DOSBox ด้วย `-conf` (ไฟล์ `dospad.cfg` เดิมไม่ถูกแตะ)

## หมายเหตุ

โค้ดชุดนี้เขียนและตรวจแบบ static โดยไม่ได้คอมไพล์/รันบน Xcode จริง — ถ้า Actions แจ้ง error ให้ดูไฟล์ `build.log` (ใน Artifacts) แล้วส่งกลับมาแก้ได้

ลิขสิทธิ์: DOSBox (GPL-2.0), SDL (zlib), โค้ด DOSPad เดิมโดย Litchie / Matt Dolan ตามไฟล์ต้นฉบับ
