#!/usr/bin/env python3
"""Adds the DOSPad 1.0 'Modern' sources to dospad.xcodeproj and modernises build settings.
Idempotent: running it twice does nothing the second time."""
import re, sys, hashlib, os

P = 'dospad.xcodeproj/project.pbxproj'
t = open(P, encoding='utf-8').read()
if 'DOSPad Modern' in t:
    print('already patched'); sys.exit(0)

def newid(name):
    return 'D0' + hashlib.md5(name.encode()).hexdigest()[:22].upper()

files = sorted(f for f in os.listdir('dospad/Modern') if f.endswith(('.h', '.m')))
refs, builds, group_children, source_files = [], [], [], []
for f in files:
    rid = newid('ref' + f)
    ftype = 'sourcecode.c.h' if f.endswith('.h') else 'sourcecode.c.objc'
    refs.append(f'\t\t{rid} /* {f} */ = {{isa = PBXFileReference; fileEncoding = 4; lastKnownFileType = {ftype}; path = {f}; sourceTree = "<group>"; }};\n')
    group_children.append(f'\t\t\t\t{rid} /* {f} */,\n')
    if f.endswith('.m'):
        bid = newid('build' + f)
        builds.append(f'\t\t{bid} /* {f} in Sources */ = {{isa = PBXBuildFile; fileRef = {rid} /* {f} */; settings = {{COMPILER_FLAGS = "-fobjc-arc"; }}; }};\n')
        source_files.append(f'\t\t\t\t{bid} /* {f} in Sources */,\n')

# --- UniformTypeIdentifiers + GameController frameworks
uti_ref = newid('ref-uti'); uti_build = newid('build-uti')
gc_build = newid('build-gc')
refs.append(f'\t\t{uti_ref} /* UniformTypeIdentifiers.framework */ = {{isa = PBXFileReference; lastKnownFileType = wrapper.framework; name = UniformTypeIdentifiers.framework; path = System/Library/Frameworks/UniformTypeIdentifiers.framework; sourceTree = SDKROOT; }};\n')
builds.append(f'\t\t{uti_build} /* UniformTypeIdentifiers.framework in Frameworks */ = {{isa = PBXBuildFile; fileRef = {uti_ref} /* UniformTypeIdentifiers.framework */; }};\n')
builds.append(f'\t\t{gc_build} /* GameController.framework in Frameworks */ = {{isa = PBXBuildFile; fileRef = 9222DD551CC44A9F00B321B9 /* GameController.framework */; }};\n')

# --- insert into sections
t = t.replace('/* End PBXBuildFile section */', ''.join(builds) + '/* End PBXBuildFile section */', 1)
t = t.replace('/* End PBXFileReference section */', ''.join(refs) + '/* End PBXFileReference section */', 1)

group_id = newid('group-modern')
group = (f'\t\t{group_id} /* Modern */ = {{\n\t\t\tisa = PBXGroup;\n\t\t\tchildren = (\n' + ''.join(group_children) +
         '\t\t\t);\n\t\t\tname = Modern;\n\t\t\tpath = Modern;\n\t\t\tsourceTree = "<group>";\n\t\t};\n')
t = t.replace('/* End PBXGroup section */', group + '/* End PBXGroup section */', 1)

# add group to the dospad group (E77DAFAF11B5D83600B78E69)
m = re.search(r'(E77DAFAF11B5D83600B78E69 /\* dospad \*/ = \{\s*isa = PBXGroup;\s*children = \(\n)', t)
t = t[:m.end()] + f'\t\t\t\t{group_id} /* Modern */,\n' + t[m.end():]

# sources phase of dospad (E71E60DD11B5502700EC5A05)
m = re.search(r'(E71E60DD11B5502700EC5A05 /\* Sources \*/ = \{\s*isa = PBXSourcesBuildPhase;\s*buildActionMask = \d+;\s*files = \(\n)', t)
t = t[:m.end()] + ''.join(source_files) + t[m.end():]

# frameworks phase of dospad (E71E60DE11B5502700EC5A05): drop dead libs, add new frameworks
m = re.search(r'(E71E60DE11B5502700EC5A05 /\* Frameworks \*/ = \{\s*isa = PBXFrameworksBuildPhase;.*?files = \()(.*?)(\);)', t, re.S)
body = m.group(2)
body = re.sub(r'\t+E77DB05C11B5E17500B78E69 /\* libstdc\+\+\.dylib in Frameworks \*/,\n', '', body)
body = re.sub(r'\t+E79E4A0111EC6BF400DEAA7B /\* libc\.dylib in Frameworks \*/,\n', '', body)
body += f'\t\t\t\t{uti_build} /* UniformTypeIdentifiers.framework in Frameworks */,\n\t\t\t\t{gc_build} /* GameController.framework in Frameworks */,\n\t\t\t'
t = t[:m.start(2)] + body + t[m.end(2):]

# framework refs group (so Xcode shows them)
m = re.search(r'(29B97323FDCFA39411CA2CEA /\* Frameworks \*/ = \{\s*isa = PBXGroup;\s*children = \(\n)', t)
t = t[:m.end()] + f'\t\t\t\t{uti_ref} /* UniformTypeIdentifiers.framework */,\n' + t[m.end():]

# --- build settings
t = re.sub(r'IPHONEOS_DEPLOYMENT_TARGET = [\d.]+;', 'IPHONEOS_DEPLOYMENT_TARGET = 14.0;', t)
t = re.sub(r'VALID_ARCHS = "[^"]*";', 'VALID_ARCHS = arm64;', t)

LD = ('OTHER_LDFLAGS = (\n\t\t\t\t\t"-framework",\n\t\t\t\t\tFoundation,\n\t\t\t\t\t"-framework",\n\t\t\t\t\tUIKit,\n\t\t\t\t);')
NEW_LD = ('OTHER_LDFLAGS = (\n\t\t\t\t\t"-framework",\n\t\t\t\t\tFoundation,\n\t\t\t\t\t"-framework",\n\t\t\t\t\tUIKit,\n'
          '\t\t\t\t\t"-framework",\n\t\t\t\t\tGameController,\n\t\t\t\t\t"-framework",\n\t\t\t\t\tUniformTypeIdentifiers,\n'
          '\t\t\t\t\t"-framework",\n\t\t\t\t\tAVFoundation,\n\t\t\t\t\t"-framework",\n\t\t\t\t\tCoreMIDI,\n'
          '\t\t\t\t\t"-lc++",\n\t\t\t\t\t"-lz",\n\t\t\t\t);')
assert LD in t
t = t.replace(LD, NEW_LD)
# the dospad Debug config already had a HEADER_SEARCH_PATHS line -> remove it (we added a fuller one)
m = re.search(r'E71E60E311B5502800EC5A05 /\* Debug \*/ = \{.*?\n\t\t\};', t, re.S)
blk = m.group(0).replace('\t\t\t\tHEADER_SEARCH_PATHS = ./include;\n', '')
t = t[:m.start()] + blk + t[m.end():]
t = t.replace('PRODUCT_BUNDLE_IDENTIFIER = DosFor.iPad.iOS;',
              'PRODUCT_BUNDLE_IDENTIFIER = com.dospad.app;\n\t\t\t\tHEADER_SEARCH_PATHS = (\n\t\t\t\t\t"./include",\n\t\t\t\t\t"./SDL/include",\n\t\t\t\t\t"./dosbox/include",\n\t\t\t\t);\n\t\t\t\tENABLE_BITCODE = NO;\n\t\t\t\tMARKETING_VERSION = 1.0;\n\t\t\t\tCURRENT_PROJECT_VERSION = 1;')
t = t.replace('/* Begin PBXBuildFile section */', '/* DOSPad Modern — patched by tools/patch_pbxproj.py */\n/* Begin PBXBuildFile section */', 1)

open(P, 'w', encoding='utf-8').write(t)
print('patched; added', len(files), 'files')
