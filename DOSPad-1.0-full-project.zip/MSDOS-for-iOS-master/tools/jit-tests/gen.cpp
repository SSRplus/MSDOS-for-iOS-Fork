#include "stub.h"
#include "../../dosbox/src/cpu/core_dynrec/risc_arm64.h"
#include <vector>
static Bit8u buf[65536];
static void dump(const char* name){ printf("%s:",name); for(Bit8u*p=buf;p<cache.pos;p+=4){Bit32u v;memcpy(&v,p,4);printf(" %08x",v);} printf("\n"); cache.pos=buf; }
int main(){
  cache.pos=buf;
  static Bit32u mem32[4]; static Bit16u mem16[4];
  gen_mov_regs(19,0); dump("mov_x19_x0");
  gen_mov_word_to_reg(2,&mem32[1],true); dump("ld32");
  gen_mov_word_to_reg(2,&mem32[1],false); dump("ld16");
  gen_mov_word_to_reg_imm(3,0x1234); dump("movw_imm");
  gen_mov_dword_to_reg_imm(3,0xdeadbeef); dump("movd_imm");
  gen_mov_word_from_reg(5,&mem32[2],true); dump("st32");
  gen_mov_word_from_reg(5,&mem16[1],false); dump("st16");
  gen_mov_byte_to_reg_low(4,&mem32[0]); dump("ldb");
  gen_mov_byte_from_reg_low(4,&mem32[0]); dump("stb");
  gen_extend_byte(true,0); gen_extend_byte(false,1); gen_extend_word(true,2); gen_extend_word(false,3); dump("ext");
  gen_add(0,&mem32[0]); dump("add_mem");
  gen_add_imm(0,5); gen_add_imm(0,0x12345); gen_add_imm(0,(Bit32u)-8); dump("add_imm");
  gen_and_imm(0,0xff00ff); dump("and_imm");
  gen_mov_direct_dword(&mem32[3],0x11223344); dump("direct_dword");
  gen_mov_direct_ptr(&mem32[0],(Bit64u)0x1122334455667788ull); dump("direct_ptr");
  gen_add_direct_byte(&mem32[0],-3); dump("add_direct_byte");
  gen_add_direct_word(&mem32[0],0x12345,true); dump("add_direct_dword");
  gen_add_direct_word(&mem16[0],0x1234,false); dump("add_direct_word");
  gen_sub_direct_word(&mem32[0],7,true); dump("sub_direct_dword");
  gen_lea(19,8,2,0x10); dump("lea3");
  gen_lea(19,3,-4); dump("lea2");
  gen_run_code(); dump("runcode");
  gen_return_function(); dump("ret");
  Bit64u b=gen_create_branch_on_zero(0,true); gen_mov_regs(1,2); gen_fill_branch(b); dump("cbz");
  b=gen_create_branch_on_nonzero(0,false); gen_mov_regs(1,2); gen_fill_branch(b); dump("tst_ne16");
  b=gen_create_branch_long_nonzero(0,false); gen_mov_regs(1,2); gen_mov_regs(1,2); gen_fill_branch_long(b); dump("tst_ne8");
  b=gen_create_branch_long_leqzero(0); gen_fill_branch_long(b); dump("leq");
  gen_jmp_ptr(&mem32[0],24); dump("jmp_ptr");
  Bit64u pos=gen_call_function_setup((void*)0x0000000102030405ull,2); gen_fill_function_ptr((Bit8u*)pos,(void*)0x00000001AABBCCDDull,9999); dump("call_patched");
  pos=gen_call_function_setup((void*)0x1,2); gen_fill_function_ptr((Bit8u*)pos,(void*)0x2,t_ADDd); dump("call_add");
  gen_load_param_imm(0x10001,2); gen_load_param_reg(19,0); gen_load_param_mem((Bitu)&mem32[0],1); dump("params");
  return 0;
}
