import struct, sys
MASK64=(1<<64)-1; MASK32=(1<<32)-1
class CPU:
    def __init__(s, code, base):
        s.code=code; s.base=base; s.x=[0]*32; s.sp=0; s.pc=base; s.mem={}; s.hooks={}; s.nz=(0,0); s.steps=0
    # memory (byte dict)
    def rd(s,a,n): return int.from_bytes(bytes(s.mem.get(a+i,0) for i in range(n)),'little')
    def wr(s,a,n,v):
        for i,b in enumerate(v.to_bytes(n,'little')): s.mem[a+i]=b
    def reg(s,r,x=True,sp=False):
        if r==31: return s.sp if sp else 0
        return s.x[r] if x else s.x[r]&MASK32
    def setr(s,r,v,x=True,sp=False):
        v&= MASK64 if x else MASK32
        if r==31:
            if sp: s.sp=v
            return
        s.x[r]=v
    def fetch(s):
        off=s.pc-s.base
        return struct.unpack_from('<I',s.code,off)[0]
    def flags(s,res32,a,b,sub=True):
        r=res32&MASK32; s.nz=(1 if r>>31 else 0, 1 if r==0 else 0)
        # signed overflow for sub
        sa=a-(1<<32) if a>>31 else a; sb=b-(1<<32) if b>>31 else b
        s.v = ((sa-sb) != (r-(1<<32) if r>>31 else r)) if sub else False
    def cond(s,c):
        N,Z=s.nz
        if c==0: return Z==1
        if c==1: return Z==0
        if c==0xD: return Z==1 or (N!=(1 if getattr(s,'v',False) else 0))
        raise Exception('cond %x'%c)
    def step(s):
        i=s.fetch(); s.steps+=1
        if s.steps>20000: raise Exception('too many steps')
        pc=s.pc; s.pc+=4
        if i==0xD503201F: return
        if i==0xD65F03C0: s.pc=s.x[30]; return
        top=i&0xFF800000
        # move wide
        if (i&0x1F800000)==0x12800000:
            sf=i>>31; opc=(i>>29)&3; hw=(i>>21)&3; imm=(i>>5)&0xFFFF; rd=i&31
            if opc==2: s.setr(rd,imm<<(16*hw),bool(sf))
            elif opc==3:
                cur=s.reg(rd,bool(sf)); cur&=~(0xFFFF<<(16*hw)); s.setr(rd,cur|(imm<<(16*hw)),bool(sf))
            else: raise Exception('movn')
            return
        # orr/and/eor/add/sub shifted reg (32 or 64)
        if (i&0x1F200000)==0x0A000000 or (i&0x1F200000)==0x0B000000:
            sf=i>>31; x=bool(sf); opc=(i>>29)&3; rm=(i>>16)&31; sh=(i>>10)&63; rn=(i>>5)&31; rd=i&31
            logic=((i>>24)&0x1F)==0x0A
            a=s.reg(rn,x); b=s.reg(rm,x)
            b=(b<<sh)&(MASK64 if x else MASK32)
            if logic:
                r={0:a&b,1:a|b,2:a^b,3:a&b}[opc]
            else:
                r=(a+b) if opc==0 else (a-b)
            s.setr(rd,r,x); return
        # add/sub immediate
        if (i&0x1F000000)==0x11000000:
            sf=i>>31; x=bool(sf); op=(i>>30)&1; S=(i>>29)&1; imm=(i>>10)&0xFFF; rn=(i>>5)&31; rd=i&31
            a=s.reg(rn,x,sp=True); r=(a-imm) if op else (a+imm)
            if S:
                s.flags(r,a&MASK32,imm,sub=bool(op))
                if rd!=31: s.setr(rd,r,x)
            else: s.setr(rd,r,x,sp=True)
            return
        # bitfield (ubfm/sbfm) 32-bit
        if (i&0x7F800000) in (0x53000000,0x13000000):
            signed=(i&0x7F800000)==0x13000000
            immr=(i>>16)&63; imms=(i>>10)&63; rn=(i>>5)&31; rd=i&31
            v=s.reg(rn,False)
            if imms>=immr:
                w=imms-immr+1; f=(v>>immr)&((1<<w)-1)
                if signed and (f>>(w-1))&1: f-= (1<<w)
                s.setr(rd,f,False)
            else:
                # lsl form
                sh=32-immr; s.setr(rd,(v<<sh)&MASK32,False)
            return
        # ands immediate (tst) 32-bit
        if (i&0x7F800000)==0x72000000:
            imms=(i>>10)&63; rn=(i>>5)&31; rd=i&31
            mask=(1<<(imms+1))-1; r=s.reg(rn,False)&mask
            s.nz=(r>>31 &1, 1 if r==0 else 0); s.v=False
            if rd!=31: s.setr(rd,r,False)
            return
        # ldr/str unsigned imm
        if (i&0x3B000000)==0x39000000:
            size=i>>30; opc=(i>>22)&3; imm=(i>>10)&0xFFF; rn=(i>>5)&31; rt=i&31
            a=s.reg(rn,True,sp=True)+(imm<<size); n=1<<size
            if opc==0: s.wr(a,n,s.reg(rt,n==8)&((1<<(8*n))-1))
            elif opc==1: s.setr(rt,s.rd(a,n),n==8)
            else: raise Exception('ldr opc')
            return
        # stp/ldp 64-bit pre/post index
        if (i&0x7E000000)==0x28000000 and (i>>31)==1:
            idx=(i>>23)&3; L=(i>>22)&1; imm7=(i>>15)&0x7F
            if imm7>=64: imm7-=128
            rt2=(i>>10)&31; rn=(i>>5)&31; rt=i&31; off=imm7*8
            base=s.reg(rn,True,sp=True)
            if idx==3: base+=off; addr=base   # pre
            elif idx==1: addr=base            # post
            else: addr=base+off
            if L: s.setr(rt,s.rd(addr,8)); s.setr(rt2,s.rd(addr+8,8))
            else: s.wr(addr,8,s.reg(rt)); s.wr(addr+8,8,s.reg(rt2))
            if idx==1: base+=off
            if idx in(1,3): s.setr(rn,base,True,sp=True)
            return
        # adr
        if (i&0x9F000000)==0x10000000:
            immlo=(i>>29)&3; immhi=(i>>5)&0x7FFFF; off=(immhi<<2)|immlo
            s.setr(i&31,pc+off); return
        # br/blr
        if (i&0xFFFFFC1F)==0xD61F0000: s.pc=s.reg((i>>5)&31); return
        if (i&0xFFFFFC1F)==0xD63F0000:
            tgt=s.reg((i>>5)&31); s.x[30]=s.pc
            if tgt in s.hooks: s.hooks[tgt](s); s.pc=s.x[30]; s.x[30]=0xDEADBEEF  # callee clobbers lr
            else: s.pc=tgt
            return
        # cbz/cbnz 32
        if (i&0x7E000000)==0x34000000:
            nz=(i>>24)&1; imm=(i>>5)&0x7FFFF
            if imm>>18: imm-=1<<19
            rt=i&31; v=s.reg(rt,False)
            if (v!=0)==bool(nz): s.pc=pc+imm*4
            return
        if (i&0xFF000010)==0x54000000:
            imm=(i>>5)&0x7FFFF
            if imm>>18: imm-=1<<19
            if s.cond(i&15): s.pc=pc+imm*4
            return
        raise Exception('unhandled %08x at %x'%(i,pc))
