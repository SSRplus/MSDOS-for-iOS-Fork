# ARM64 dynrec backend — off-device tests

Run on any Linux/macOS box with g++ and python3 (no ARM hardware needed):

    cd tools/jit-tests
    g++ -std=c++11 -fpermissive -w -o gen gen.cpp  && ./gen          # dumps the machine code of every gen_* primitive
    g++ -std=c++11 -fpermissive -w -o flow flow.cpp && ./flow        # builds a test block into flow.bin
    python3 runflow.py                                               # runs runcode -> block -> helper call -> return in a tiny ARM64 emulator

`runflow.py` checks stack/callee-saved register restore, helper calls that clobber x30, memory ops, branches,
lea, the flag-less inline ADD patch and block return codes. Syntax check of the whole core:

    g++ -fsyntax-only -std=gnu++11 -w -fpermissive -DHAVE_CONFIG_H -DC_DYNREC=1 -DC_TARGETCPU=ARMV8LE \
        -I../../dosbox -I../../dosbox/include ../../dosbox/src/cpu/core_dynrec.cpp
