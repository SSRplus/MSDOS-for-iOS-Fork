import sys; sys.path.insert(0,'.')
from a64emu import *
code=open('flow.bin','rb').read()
blockoff=48
base=0x400000
c=CPU(code,base)
M=lambda o:0x100000+o
c.wr(M(0),4,0x1000); c.wr(M(4),2,0x1234abcd&0xffff); c.wr(M(6),1,0x5a); c.wr(M(16),2,0xFFF0); c.wr(M(20),4,100); c.wr(M(40),4,0)
# helper(x0,x1,x2) -> x0+x1+x2
def helper(cpu): cpu.x[0]=(cpu.x[0]+cpu.x[1]+cpu.x[2])&MASK32; cpu.x[16]=0
c.hooks[0x7000]=helper
c.hooks[0x7100]=lambda cpu: (_ for _ in ()).throw(Exception('inline add was NOT inlined'))
# callee-saved sentinels
for r in (19,20,29): c.x[r]=0x1000+r
SENT=0x900000; c.x[30]=SENT; c.sp=0x800000; sp0=c.sp
c.x[0]=base+blockoff; c.pc=base   # runcode(block)
while c.pc!=SENT: c.step()
chk=lambda n,got,exp: print(('OK  ' if got==exp else 'FAIL'),n,hex(got),hex(exp))
chk('return code',c.x[0],1)
chk('sp restored',c.sp,sp0)
for r in (19,20,29): chk('x%d restored'%r,c.x[r],0x1000+r)
chk('lr restored',c.x[30],SENT)
r=(0x1234abcd&0xffff)+0x5a+0x1000
chk('helper result',c.rd(M(8),4),r)
chk('lea',c.rd(M(12),4),(0x1000+(r<<2)+0x10)&MASK32)
chk('add16',c.rd(M(16),2),(0xFFF0+0x1234)&0xffff)
chk('sub32',c.rd(M(20),4),95)
chk('const',c.rd(M(24),4),0xA5A5A5A5)
chk('ptr64',c.rd(M(32),8),0x1122334455667788)
chk('branch skipped store',c.rd(M(44),4),0)
chk('branch target store',c.rd(M(48),4),222)
chk('inline add',c.rd(M(52),4),42)
chk('leq skipped',c.rd(M(56),4),0)
