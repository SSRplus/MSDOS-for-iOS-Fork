#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef uint8_t Bit8u; typedef int8_t Bit8s; typedef uint16_t Bit16u; typedef int16_t Bit16s;
typedef uint32_t Bit32u; typedef int32_t Bit32s; typedef uint64_t Bit64u; typedef int64_t Bit64s;
typedef unsigned long Bitu; typedef long Bits;
#define INLINE inline
#define E_Exit(x) do{fprintf(stderr,"E_Exit %s\n",x);exit(1);}while(0)
struct { Bit8u* pos; } cache;
static void cache_addd(Bit32u v){ memcpy(cache.pos,&v,4); cache.pos+=4; }
static void cache_addb(Bit8u v){ *cache.pos++=v; }
enum { t_ADDb=0,t_ADDw,t_ADDd,t_ORb,t_ORw,t_ORd,t_ANDb,t_ANDw,t_ANDd,t_SUBb,t_SUBw,t_SUBd,t_XORb,t_XORw,t_XORd,
 t_CMPb,t_CMPw,t_CMPd,t_INCb,t_INCw,t_INCd,t_DECb,t_DECw,t_DECd,t_TESTb,t_TESTw,t_TESTd,t_NEGb,t_NEGw,t_NEGd };
#define DRC_JIT_WRITE_END() do{}while(0)
