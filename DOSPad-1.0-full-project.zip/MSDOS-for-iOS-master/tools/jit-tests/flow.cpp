#include "stub.h"
#include "../../dosbox/src/cpu/core_dynrec/risc_arm64.h"
static Bit8u buf[8192];
#define CODEBASE 0x400000ull
#define M(x) ((void*)(0x100000ull+(x)))
int main(){
  cache.pos=buf;
  // runcode at offset 0
  gen_run_code(); gen_return_function();
  while((cache.pos-buf)%16) cache_addd(0);
  Bit32u blockoff=cache.pos-buf;
  // block: x0 = [0x100000] (dword); param0 = x0, param1 = imm 7; call helper 0x7000; store x0 -> [0x100008]
  gen_mov_word_to_reg(FC_ADDR, M(0), true);                 // x19 = mem[0]  (FC_ADDR)
  gen_mov_word_to_reg(FC_OP1, M(4), false);                 // x0 = (u16) mem[4]
  gen_mov_byte_to_reg_low(FC_OP2, M(6));                    // x1 = (u8) mem[6]
  gen_load_param_reg(FC_ADDR,2);                            // x2 = x19
  Bit64u site=gen_call_function_setup((void*)0x7000ull,3);  // helper(x0,x1,x2)
  gen_mov_word_from_reg(FC_RETOP, M(8), true);              // mem[8] = x0
  gen_lea(FC_ADDR, FC_RETOP, 2, 0x10);                      // x19 += x0<<2 + 0x10
  gen_mov_word_from_reg(FC_ADDR, M(12), true);              // mem[12] = x19
  gen_add_direct_word(M(16), 0x1234, false);                // mem16[16] += 0x1234
  gen_sub_direct_word(M(20), 5, true);                      // mem32[20] -= 5
  gen_mov_direct_dword(M(24), 0xA5A5A5A5);                  // mem32[24] = const
  gen_mov_direct_ptr(M(32), 0x1122334455667788ull);         // mem64[32]
  // branch: if (mem32[40]==0) skip the next two stores
  gen_mov_word_to_reg(FC_OP1, M(40), true);
  Bit64u br=gen_create_branch_on_zero(FC_OP1,true);
  gen_mov_direct_dword(M(44), 111);
  gen_fill_branch(br);
  gen_mov_direct_dword(M(48), 222);
  // inline flag-less add: patch call site of a second call
  gen_mov_dword_to_reg_imm(FC_OP1, 40); gen_mov_dword_to_reg_imm(FC_OP2, 2);
  Bit64u s2=gen_call_function_setup((void*)0x7100ull,2);
  gen_fill_function_ptr((Bit8u*)s2,(void*)0x7100ull,t_ADDd);   // becomes add w0,w0,w1
  gen_mov_word_from_reg(FC_RETOP, M(52), true);
  // loop-ish: leqzero branch not taken then taken
  gen_mov_dword_to_reg_imm(FC_OP1, 0);
  Bit64u l=gen_create_branch_long_leqzero(FC_OP1);
  gen_mov_direct_dword(M(56), 999);   // skipped
  gen_fill_branch_long(l);
  // return code 1 like dyn_return(BR_Link1)
  gen_mov_dword_to_reg_imm(FC_RETOP, 1);
  gen_return_function();
  FILE*f=fopen("flow.bin","wb"); fwrite(buf,1,cache.pos-buf,f); fclose(f);
  printf("%u %llu\n", blockoff, (unsigned long long)(site-(Bit64u)buf));
}
