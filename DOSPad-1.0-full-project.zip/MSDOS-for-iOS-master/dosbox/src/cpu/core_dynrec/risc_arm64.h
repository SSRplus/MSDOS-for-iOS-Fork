/*
 *  DOSPad: AArch64 (ARM64, Apple ABI) backend for the DOSBox 0.74 dynrec core.
 *
 *  Written for DOSPad 1.0 following the structure of risc_x64.h / risc_armv4le-*.h.
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 */


// ---------------------------------------------------------------------------
// capabilities of this backend
// ---------------------------------------------------------------------------

// FC_ADDR lives in a callee-saved register, so no protection is needed
// #define DRC_PROTECT_ADDR_REG

// try to use non-flags generating functions if possible
#define DRC_FLAGS_INVALIDATION
// try to replace _simple functions by code
#define DRC_FLAGS_INVALIDATION_DCODE

// type with the same size as a pointer
#define DRC_PTR_SIZE_IM Bit64u

// calling convention modifier
#define DRC_CALL_CONV	/* nothing */
#define DRC_FC			/* nothing */


// ---------------------------------------------------------------------------
// register mapping
//
//   x0  FC_RETOP / FC_OP1 / FC_TMP_BA1 / parameter 0 / return value
//   x1  FC_OP2 / FC_TMP_BA2 / parameter 1
//   x2  parameter 2
//   x3  parameter 3
//   x8  TEMP_REG_DRC (LEA temporary)
//   x15 scratch (large immediates)  x16/x17 scratch (addresses / values)
//   x19 FC_ADDR (callee-saved, survives helper calls)
//   x20 FC_OP3  (callee-saved)
//   x18 is reserved by Apple and never touched; x29/x30 are managed by gen_run_code
// ---------------------------------------------------------------------------

typedef Bit8u HostReg;

#define HOST_x0   0
#define HOST_x1   1
#define HOST_x2   2
#define HOST_x3   3
#define HOST_x8   8
#define HOST_x15 15
#define HOST_x16 16
#define HOST_x17 17
#define HOST_x19 19
#define HOST_x20 20
#define HOST_x30 30
#define HOST_xzr 31
#define HOST_sp  31

// register that holds function return values
#define FC_RETOP HOST_x0

// register used for address calculations
#define FC_ADDR HOST_x19

// register that holds the first parameter
#define FC_OP1 HOST_x0

// register that holds the second parameter
#define FC_OP2 HOST_x1

// special register that holds the third parameter for _R3 calls
#define FC_OP3 HOST_x20

// registers that hold byte-accessible temporary values (every register is byte accessible on AArch64)
#define FC_TMP_BA1 HOST_x0
#define FC_TMP_BA2 HOST_x1

// temporary register for LEA
#define TEMP_REG_DRC HOST_x8

#define A64_SCRATCH_A HOST_x16
#define A64_SCRATCH_V HOST_x17
#define A64_SCRATCH_I HOST_x15


// ---------------------------------------------------------------------------
// instruction encoders
// ---------------------------------------------------------------------------

#define A64_NOP					0xD503201Fu

// move wide (hw = 16-bit chunk index)
#define A64_MOVZ_W(rd,imm,hw)	(0x52800000u | ((Bit32u)(hw)<<21) | (((Bit32u)(imm)&0xffffu)<<5) | (rd))
#define A64_MOVK_W(rd,imm,hw)	(0x72800000u | ((Bit32u)(hw)<<21) | (((Bit32u)(imm)&0xffffu)<<5) | (rd))
#define A64_MOVZ_X(rd,imm,hw)	(0xD2800000u | ((Bit32u)(hw)<<21) | (((Bit32u)(imm)&0xffffu)<<5) | (rd))
#define A64_MOVK_X(rd,imm,hw)	(0xF2800000u | ((Bit32u)(hw)<<21) | (((Bit32u)(imm)&0xffffu)<<5) | (rd))

// mov xd, xm  (orr xd, xzr, xm)
#define A64_MOV_X(rd,rm)		(0xAA0003E0u | ((rm)<<16) | (rd))

// add/sub immediate (imm12, no shift)
#define A64_ADD_IMM_W(rd,rn,imm)	(0x11000000u | (((Bit32u)(imm)&0xfffu)<<10) | ((rn)<<5) | (rd))
#define A64_SUB_IMM_W(rd,rn,imm)	(0x51000000u | (((Bit32u)(imm)&0xfffu)<<10) | ((rn)<<5) | (rd))

// add/sub/logic, register (shift type LSL)
#define A64_ADD_REG_W(rd,rn,rm)				(0x0B000000u | ((rm)<<16) | ((rn)<<5) | (rd))
#define A64_ADD_REG_LSL_W(rd,rn,rm,sh)		(0x0B000000u | ((rm)<<16) | (((Bit32u)(sh)&31u)<<10) | ((rn)<<5) | (rd))
#define A64_SUB_REG_W(rd,rn,rm)				(0x4B000000u | ((rm)<<16) | ((rn)<<5) | (rd))
#define A64_ORR_REG_W(rd,rn,rm)				(0x2A000000u | ((rm)<<16) | ((rn)<<5) | (rd))
#define A64_AND_REG_W(rd,rn,rm)				(0x0A000000u | ((rm)<<16) | ((rn)<<5) | (rd))
#define A64_EOR_REG_W(rd,rn,rm)				(0x4A000000u | ((rm)<<16) | ((rn)<<5) | (rd))

// lsl wd, wn, #sh  (ubfm wd, wn, #(32-sh)&31, #(31-sh))
#define A64_LSL_IMM_W(rd,rn,sh)	(0x53000000u | ((((32u-(sh))&31u))<<16) | ((31u-(sh))<<10) | ((rn)<<5) | (rd))

// extend
#define A64_UXTB_W(rd,rn)		(0x53001C00u | ((rn)<<5) | (rd))
#define A64_UXTH_W(rd,rn)		(0x53003C00u | ((rn)<<5) | (rd))
#define A64_SXTB_W(rd,rn)		(0x13001C00u | ((rn)<<5) | (rd))
#define A64_SXTH_W(rd,rn)		(0x13003C00u | ((rn)<<5) | (rd))

// load / store, unsigned scaled immediate offset (offset is in bytes and must be a multiple of the access size)
#define A64_LDR_W(rt,rn,off)	(0xB9400000u | ((((Bit32u)(off))>>2)<<10) | ((rn)<<5) | (rt))
#define A64_LDR_X(rt,rn,off)	(0xF9400000u | ((((Bit32u)(off))>>3)<<10) | ((rn)<<5) | (rt))
#define A64_LDRH(rt,rn,off)		(0x79400000u | ((((Bit32u)(off))>>1)<<10) | ((rn)<<5) | (rt))
#define A64_LDRB(rt,rn,off)		(0x39400000u | ((((Bit32u)(off)))<<10) | ((rn)<<5) | (rt))
#define A64_STR_W(rt,rn,off)	(0xB9000000u | ((((Bit32u)(off))>>2)<<10) | ((rn)<<5) | (rt))
#define A64_STR_X(rt,rn,off)	(0xF9000000u | ((((Bit32u)(off))>>3)<<10) | ((rn)<<5) | (rt))
#define A64_STRH(rt,rn,off)		(0x79000000u | ((((Bit32u)(off))>>1)<<10) | ((rn)<<5) | (rt))
#define A64_STRB(rt,rn,off)		(0x39000000u | ((((Bit32u)(off)))<<10) | ((rn)<<5) | (rt))

// stp xt1, xt2, [sp, #-16]!   /   ldp xt1, xt2, [sp], #16
#define A64_STP_PRE16(rt,rt2)	(0xA9BF0000u | ((rt2)<<10) | (31u<<5) | (rt))
#define A64_LDP_POST16(rt,rt2)	(0xA8C10000u | ((rt2)<<10) | (31u<<5) | (rt))

// adr xd, #byte_offset
#define A64_ADR(rd,off)			(0x10000000u | ((((Bit32u)(off))&3u)<<29) | (((((Bit32u)(off))>>2)&0x7ffffu)<<5) | (rd))

// branches
#define A64_BR(rn)				(0xD61F0000u | ((rn)<<5))
#define A64_BLR(rn)				(0xD63F0000u | ((rn)<<5))
#define A64_RET					0xD65F03C0u
#define A64_CBZ_W(rt)			(0x34000000u | (rt))
#define A64_CBNZ_W(rt)			(0x35000000u | (rt))
#define A64_BCOND(cond)			(0x54000000u | (cond))
#define A64_COND_EQ 0x0u
#define A64_COND_NE 0x1u
#define A64_COND_LE 0xDu

// compare / test against constants
#define A64_CMP_ZERO_W(rn)		(0x7100001Fu | ((rn)<<5))	// subs wzr, wn, #0
#define A64_TST_FF_W(rn)		(0x72001C1Fu | ((rn)<<5))	// ands wzr, wn, #0xff
#define A64_TST_FFFF_W(rn)		(0x72003C1Fu | ((rn)<<5))	// ands wzr, wn, #0xffff


// ---------------------------------------------------------------------------
// helpers
// ---------------------------------------------------------------------------

static INLINE void a64_emit(Bit32u ins) {
	cache_addd(ins);
}

// load a 32bit constant into the lower half of a register (upper half is zeroed)
static void a64_mov_imm32(HostReg rd,Bit32u imm) {
	if (!(imm&0xffff0000u)) {
		a64_emit(A64_MOVZ_W(rd,imm&0xffff,0));
	} else if (!(imm&0xffffu)) {
		a64_emit(A64_MOVZ_W(rd,imm>>16,1));
	} else {
		a64_emit(A64_MOVZ_W(rd,imm&0xffff,0));
		a64_emit(A64_MOVK_W(rd,imm>>16,1));
	}
}

// load an arbitrary 64bit constant
static void a64_mov_imm64(HostReg rd,Bit64u imm) {
	bool first=true;
	for (Bitu hw=0;hw<4;hw++) {
		Bit32u chunk=(Bit32u)((imm>>(16*hw))&0xffffu);
		if (!chunk) continue;
		if (first) a64_emit(A64_MOVZ_X(rd,chunk,hw));
		else a64_emit(A64_MOVK_X(rd,chunk,hw));
		first=false;
	}
	if (first) a64_emit(A64_MOVZ_X(rd,0,0));
}

// add a 32bit constant to a register (rd = rn + imm, 32bit arithmetic)
static void a64_add_imm32(HostReg rd,HostReg rn,Bit32u imm) {
	if (imm<4096u) {
		if (imm || rd!=rn) a64_emit(A64_ADD_IMM_W(rd,rn,imm));
	} else if ((Bit32u)(0u-imm)<4096u) {
		a64_emit(A64_SUB_IMM_W(rd,rn,0u-imm));
	} else {
		a64_mov_imm32(A64_SCRATCH_I,imm);
		a64_emit(A64_ADD_REG_W(rd,rn,A64_SCRATCH_I));
	}
}

// subtract a 32bit constant from a register
static void a64_sub_imm32(HostReg rd,HostReg rn,Bit32u imm) {
	if (imm<4096u) {
		if (imm || rd!=rn) a64_emit(A64_SUB_IMM_W(rd,rn,imm));
	} else if ((Bit32u)(0u-imm)<4096u) {
		a64_emit(A64_ADD_IMM_W(rd,rn,0u-imm));
	} else {
		a64_mov_imm32(A64_SCRATCH_I,imm);
		a64_emit(A64_SUB_REG_W(rd,rn,A64_SCRATCH_I));
	}
}

// fixed size sequence that loads a function pointer into x16 and calls it
// 4 x (movz/movk) + blr  ==  5 instructions; gen_fill_function_ptr() depends on this layout
#define A64_CALL_SEQ_LEN 5

static void a64_call_seq(void* func) {
	Bit64u addr=(Bit64u)func;
	a64_emit(A64_MOVZ_X(A64_SCRATCH_A,(Bit32u)(addr&0xffffu),0));
	a64_emit(A64_MOVK_X(A64_SCRATCH_A,(Bit32u)((addr>>16)&0xffffu),1));
	a64_emit(A64_MOVK_X(A64_SCRATCH_A,(Bit32u)((addr>>32)&0xffffu),2));
	a64_emit(A64_MOVK_X(A64_SCRATCH_A,(Bit32u)((addr>>48)&0xffffu),3));
	a64_emit(A64_BLR(A64_SCRATCH_A));
}


// ---------------------------------------------------------------------------
// the backend interface used by the decoder
// ---------------------------------------------------------------------------

// move a full register from reg_src to reg_dst
static void gen_mov_regs(HostReg reg_dst,HostReg reg_src) {
	if (reg_dst==reg_src) return;
	a64_emit(A64_MOV_X(reg_dst,reg_src));
}

// move a 32bit (dword==true) or 16bit (dword==false) value from memory into dest_reg
// 16bit moves may destroy the upper 16bit of the destination register
static void gen_mov_word_to_reg(HostReg dest_reg,void* data,bool dword) {
	a64_mov_imm64(dest_reg,(Bit64u)data);
	if (dword) a64_emit(A64_LDR_W(dest_reg,dest_reg,0));
	else a64_emit(A64_LDRH(dest_reg,dest_reg,0));
}

// move a 16bit constant value into dest_reg
// the upper 16bit of the destination register may be destroyed
static void gen_mov_word_to_reg_imm(HostReg dest_reg,Bit16u imm) {
	a64_emit(A64_MOVZ_W(dest_reg,imm,0));
}

// move a 32bit constant value into dest_reg
static void gen_mov_dword_to_reg_imm(HostReg dest_reg,Bit32u imm) {
	a64_mov_imm32(dest_reg,imm);
}

// move 32bit (dword==true) or 16bit (dword==false) of a register into memory
static void gen_mov_word_from_reg(HostReg src_reg,void* dest,bool dword) {
	a64_mov_imm64(A64_SCRATCH_A,(Bit64u)dest);
	if (dword) a64_emit(A64_STR_W(src_reg,A64_SCRATCH_A,0));
	else a64_emit(A64_STRH(src_reg,A64_SCRATCH_A,0));
}

// move an 8bit value from memory into dest_reg (upper 24bit zeroed)
static void gen_mov_byte_to_reg_low(HostReg dest_reg,void* data) {
	a64_mov_imm64(dest_reg,(Bit64u)data);
	a64_emit(A64_LDRB(dest_reg,dest_reg,0));
}

// same, but may use FC_OP1/FC_OP2 (all registers are byte accessible here)
static void gen_mov_byte_to_reg_low_canuseword(HostReg dest_reg,void* data) {
	gen_mov_byte_to_reg_low(dest_reg,data);
}

// move an 8bit constant value into dest_reg
static void gen_mov_byte_to_reg_low_imm(HostReg dest_reg,Bit8u imm) {
	a64_emit(A64_MOVZ_W(dest_reg,imm,0));
}

static void gen_mov_byte_to_reg_low_imm_canuseword(HostReg dest_reg,Bit8u imm) {
	gen_mov_byte_to_reg_low_imm(dest_reg,imm);
}

// move the lowest 8bit of a register into memory
static void gen_mov_byte_from_reg_low(HostReg src_reg,void* dest) {
	a64_mov_imm64(A64_SCRATCH_A,(Bit64u)dest);
	a64_emit(A64_STRB(src_reg,A64_SCRATCH_A,0));
}


// convert an 8bit word to a 32bit dword (zero- or sign-extended)
static void gen_extend_byte(bool sign,HostReg reg) {
	a64_emit(sign ? A64_SXTB_W(reg,reg) : A64_UXTB_W(reg,reg));
}

// convert a 16bit word to a 32bit dword (zero- or sign-extended)
static void gen_extend_word(bool sign,HostReg reg) {
	a64_emit(sign ? A64_SXTH_W(reg,reg) : A64_UXTH_W(reg,reg));
}


// add a 32bit value from memory to a full register
static void gen_add(HostReg reg,void* op) {
	a64_mov_imm64(A64_SCRATCH_A,(Bit64u)op);
	a64_emit(A64_LDR_W(A64_SCRATCH_V,A64_SCRATCH_A,0));
	a64_emit(A64_ADD_REG_W(reg,reg,A64_SCRATCH_V));
}

// add a 32bit constant value to a full register
static void gen_add_imm(HostReg reg,Bit32u imm) {
	a64_add_imm32(reg,reg,imm);
}

// and a 32bit constant value with a full register
static void gen_and_imm(HostReg reg,Bit32u imm) {
	a64_mov_imm32(A64_SCRATCH_I,imm);
	a64_emit(A64_AND_REG_W(reg,reg,A64_SCRATCH_I));
}


// move a 32bit constant value into memory
static void gen_mov_direct_dword(void* dest,Bit32u imm) {
	a64_mov_imm32(A64_SCRATCH_V,imm);
	a64_mov_imm64(A64_SCRATCH_A,(Bit64u)dest);
	a64_emit(A64_STR_W(A64_SCRATCH_V,A64_SCRATCH_A,0));
}

// move a 64bit constant value into a full register
static void gen_mov_reg_qword(HostReg dest_reg,Bit64u imm) {
	a64_mov_imm64(dest_reg,imm);
}

// move an address into memory
static void INLINE gen_mov_direct_ptr(void* dest,DRC_PTR_SIZE_IM imm) {
	a64_mov_imm64(A64_SCRATCH_V,(Bit64u)imm);
	a64_mov_imm64(A64_SCRATCH_A,(Bit64u)dest);
	a64_emit(A64_STR_X(A64_SCRATCH_V,A64_SCRATCH_A,0));
}


// add an 8bit constant value to a memory value
static void gen_add_direct_byte(void* dest,Bit8s imm) {
	a64_mov_imm64(A64_SCRATCH_A,(Bit64u)dest);
	a64_emit(A64_LDR_W(A64_SCRATCH_V,A64_SCRATCH_A,0));
	if (imm>=0) a64_add_imm32(A64_SCRATCH_V,A64_SCRATCH_V,(Bit32u)imm);
	else a64_sub_imm32(A64_SCRATCH_V,A64_SCRATCH_V,(Bit32u)(-(Bit32s)imm));
	a64_emit(A64_STR_W(A64_SCRATCH_V,A64_SCRATCH_A,0));
}

// add a 32bit (dword==true) or 16bit (dword==false) constant value to a memory value
static void gen_add_direct_word(void* dest,Bit32u imm,bool dword) {
	a64_mov_imm64(A64_SCRATCH_A,(Bit64u)dest);
	if (dword) {
		a64_emit(A64_LDR_W(A64_SCRATCH_V,A64_SCRATCH_A,0));
		a64_add_imm32(A64_SCRATCH_V,A64_SCRATCH_V,imm);
		a64_emit(A64_STR_W(A64_SCRATCH_V,A64_SCRATCH_A,0));
	} else {
		a64_emit(A64_LDRH(A64_SCRATCH_V,A64_SCRATCH_A,0));
		a64_add_imm32(A64_SCRATCH_V,A64_SCRATCH_V,imm&0xffffu);
		a64_emit(A64_STRH(A64_SCRATCH_V,A64_SCRATCH_A,0));
	}
}

// subtract an 8bit constant value from a memory value
static void gen_sub_direct_byte(void* dest,Bit8s imm) {
	a64_mov_imm64(A64_SCRATCH_A,(Bit64u)dest);
	a64_emit(A64_LDR_W(A64_SCRATCH_V,A64_SCRATCH_A,0));
	if (imm>=0) a64_sub_imm32(A64_SCRATCH_V,A64_SCRATCH_V,(Bit32u)imm);
	else a64_add_imm32(A64_SCRATCH_V,A64_SCRATCH_V,(Bit32u)(-(Bit32s)imm));
	a64_emit(A64_STR_W(A64_SCRATCH_V,A64_SCRATCH_A,0));
}

// subtract a 32bit (dword==true) or 16bit (dword==false) constant value from a memory value
static void gen_sub_direct_word(void* dest,Bit32u imm,bool dword) {
	a64_mov_imm64(A64_SCRATCH_A,(Bit64u)dest);
	if (dword) {
		a64_emit(A64_LDR_W(A64_SCRATCH_V,A64_SCRATCH_A,0));
		a64_sub_imm32(A64_SCRATCH_V,A64_SCRATCH_V,imm);
		a64_emit(A64_STR_W(A64_SCRATCH_V,A64_SCRATCH_A,0));
	} else {
		a64_emit(A64_LDRH(A64_SCRATCH_V,A64_SCRATCH_A,0));
		a64_sub_imm32(A64_SCRATCH_V,A64_SCRATCH_V,imm&0xffffu);
		a64_emit(A64_STRH(A64_SCRATCH_V,A64_SCRATCH_A,0));
	}
}


// effective address calculation, destination is dest_reg
// scale_reg is scaled by scale (scale_reg*(2^scale)) and
// added to dest_reg, then the immediate value is added
static INLINE void gen_lea(HostReg dest_reg,HostReg scale_reg,Bitu scale,Bits imm) {
	a64_emit(A64_ADD_REG_LSL_W(dest_reg,dest_reg,scale_reg,scale));
	if (imm) a64_add_imm32(dest_reg,dest_reg,(Bit32u)imm);
}

// effective address calculation, destination is dest_reg
// dest_reg is scaled by scale (dest_reg*(2^scale)),
// then the immediate value is added
static INLINE void gen_lea(HostReg dest_reg,Bitu scale,Bits imm) {
	if (scale) a64_emit(A64_LSL_IMM_W(dest_reg,dest_reg,scale));
	if (imm) a64_add_imm32(dest_reg,dest_reg,(Bit32u)imm);
}


// generate a call to a parameterless function
static void INLINE gen_call_function_raw(void * func) {
	a64_call_seq(func);
}

// generate a call to a function with paramcount parameters
// note: the parameters are loaded in the architecture specific way
// using the gen_load_param_ functions below
// returns the address of the call sequence, which gen_fill_function_ptr() can patch later
static Bit64u INLINE gen_call_function_setup(void * func,Bitu paramcount,bool fastcall=false) {
	Bit64u proc_addr=(Bit64u)cache.pos;
	a64_call_seq(func);
	return proc_addr;
}


// load an immediate value as param'th function parameter
static void INLINE gen_load_param_imm(Bitu imm,Bitu param) {
	if (param>3) E_Exit("I(mm) >4 params unsupported");
	a64_mov_imm32((HostReg)param,(Bit32u)imm);
}

// load an address as param'th function parameter
static void INLINE gen_load_param_addr(DRC_PTR_SIZE_IM addr,Bitu param) {
	if (param>3) E_Exit("A(ddr) >4 params unsupported");
	a64_mov_imm64((HostReg)param,(Bit64u)addr);
}

// load a host-register as param'th function parameter
static void INLINE gen_load_param_reg(Bitu reg,Bitu param) {
	if (param>3) E_Exit("R(eg) >4 params unsupported");
	gen_mov_regs((HostReg)param,(HostReg)reg);
}

// load a value from memory as param'th function parameter
static void INLINE gen_load_param_mem(Bitu mem,Bitu param) {
	if (param>3) E_Exit("R(eg) >4 params unsupported");
	gen_mov_word_to_reg((HostReg)param,(void*)mem,true);
}


// jump to an address pointed at by ptr, offset is in imm
// target = *( *ptr + imm )
static void gen_jmp_ptr(void * ptr,Bits imm=0) {
	a64_mov_imm64(A64_SCRATCH_A,(Bit64u)ptr);
	a64_emit(A64_LDR_X(A64_SCRATCH_A,A64_SCRATCH_A,0));
	if (imm>=0 && imm<32768 && (imm&7)==0) {
		a64_emit(A64_LDR_X(A64_SCRATCH_A,A64_SCRATCH_A,imm));
	} else {
		a64_mov_imm64(A64_SCRATCH_V,(Bit64u)(Bit64s)imm);
		a64_emit(0x8B000000u | (A64_SCRATCH_V<<16) | (A64_SCRATCH_A<<5) | A64_SCRATCH_A);	// add x16,x16,x17
		a64_emit(A64_LDR_X(A64_SCRATCH_A,A64_SCRATCH_A,0));
	}
	a64_emit(A64_BR(A64_SCRATCH_A));
}


// conditional branches. The branch instruction carries a 19bit word offset that is
// filled in later by gen_fill_branch(); the returned value is the address of that instruction.

// short conditional jump if register is zero
static Bit64u gen_create_branch_on_zero(HostReg reg,bool dword) {
	if (dword) {
		a64_emit(A64_CBZ_W(reg));
	} else {
		a64_emit(A64_TST_FFFF_W(reg));
		a64_emit(A64_BCOND(A64_COND_EQ));
	}
	return ((Bit64u)cache.pos-4);
}

// short conditional jump if register is nonzero
static Bit64u gen_create_branch_on_nonzero(HostReg reg,bool dword) {
	if (dword) {
		a64_emit(A64_CBNZ_W(reg));
	} else {
		a64_emit(A64_TST_FFFF_W(reg));
		a64_emit(A64_BCOND(A64_COND_NE));
	}
	return ((Bit64u)cache.pos-4);
}

// set the destination of a branch created above to the current position
static void gen_fill_branch(DRC_PTR_SIZE_IM data) {
	Bit32s words=(Bit32s)(((Bit64s)cache.pos-(Bit64s)data)>>2);
	Bit32u* ins=(Bit32u*)data;
	*ins=(*ins & ~(0x7ffffu<<5)) | (((Bit32u)words&0x7ffffu)<<5);
}

// conditional jump if register is nonzero
// for isdword==true the 32bit of the register are tested
// for isdword==false the lowest 8bit of the register are tested
static Bit64u gen_create_branch_long_nonzero(HostReg reg,bool isdword) {
	if (isdword) {
		a64_emit(A64_CBNZ_W(reg));
	} else {
		a64_emit(A64_TST_FF_W(reg));
		a64_emit(A64_BCOND(A64_COND_NE));
	}
	return ((Bit64u)cache.pos-4);
}

// compare 32bit-register against zero and jump if value less/equal than zero
static Bit64u gen_create_branch_long_leqzero(HostReg reg) {
	a64_emit(A64_CMP_ZERO_W(reg));
	a64_emit(A64_BCOND(A64_COND_LE));
	return ((Bit64u)cache.pos-4);
}

// set the destination of a "long" branch created above to the current position
static void gen_fill_branch_long(Bit64u data) {
	gen_fill_branch((DRC_PTR_SIZE_IM)data);
}


// Entry trampoline: C signature is  BlockReturn runcode(Bit8u* block)
// The return address of the generated code is kept on the stack (not in x30), because every
// call into a C helper overwrites x30. gen_return_function() pops it again.
static void gen_run_code(void) {
	a64_emit(A64_STP_PRE16(29,30));			// stp x29,x30,[sp,#-16]!
	a64_emit(A64_STP_PRE16(19,20));			// stp x19,x20,[sp,#-16]!
	a64_emit(A64_ADR(30,12));				// adr x30,<ret>
	a64_emit(A64_STP_PRE16(30,31));			// stp x30,xzr,[sp,#-16]!
	a64_emit(A64_BR(FC_OP1));				// br x0
	// <ret>: reached through gen_return_function() of a block
	a64_emit(A64_LDP_POST16(19,20));		// ldp x19,x20,[sp],#16
	a64_emit(A64_LDP_POST16(29,30));		// ldp x29,x30,[sp],#16
	a64_emit(A64_RET);
}

// return from a block (back into gen_run_code's <ret>)
static void gen_return_function(void) {
	a64_emit(A64_LDP_POST16(30,31));		// ldp x30,xzr,[sp],#16
	a64_emit(A64_RET);
}


#ifdef DRC_FLAGS_INVALIDATION
// called when a call to a function can be replaced by a
// call to a simpler function. `pos` is the call sequence made by a64_call_seq().
static void gen_fill_function_ptr(Bit8u * pos,void* fct_ptr,Bitu flags_type) {
	Bit32u* p=(Bit32u*)pos;
#ifdef DRC_FLAGS_INVALIDATION_DCODE
	// try to avoid function calls but rather directly fill in code
	// inputs are in x0/x1 (FC_OP1/FC_OP2), the result is expected in x0 (FC_RETOP)
	Bit32u ins=0;
	switch (flags_type) {
		case t_ADDb:
		case t_ADDw:
		case t_ADDd:
			ins=A64_ADD_REG_W(0,0,1);
			break;
		case t_ORb:
		case t_ORw:
		case t_ORd:
			ins=A64_ORR_REG_W(0,0,1);
			break;
		case t_ANDb:
		case t_ANDw:
		case t_ANDd:
			ins=A64_AND_REG_W(0,0,1);
			break;
		case t_SUBb:
		case t_SUBw:
		case t_SUBd:
			ins=A64_SUB_REG_W(0,0,1);
			break;
		case t_XORb:
		case t_XORw:
		case t_XORd:
			ins=A64_EOR_REG_W(0,0,1);
			break;
		case t_CMPb:
		case t_CMPw:
		case t_CMPd:
		case t_TESTb:
		case t_TESTw:
		case t_TESTd:
			ins=A64_NOP;
			break;
		case t_INCb:
		case t_INCw:
		case t_INCd:
			ins=A64_ADD_IMM_W(0,0,1);
			break;
		case t_DECb:
		case t_DECw:
		case t_DECd:
			ins=A64_SUB_IMM_W(0,0,1);
			break;
		case t_NEGb:
		case t_NEGw:
		case t_NEGd:
			ins=A64_SUB_REG_W(0,31,0);		// sub w0,wzr,w0
			break;
		default:
			ins=0;
			break;
	}
	if (ins) {
		p[0]=ins;
		for (Bitu i=1;i<A64_CALL_SEQ_LEN;i++) p[i]=A64_NOP;
		return;
	}
#endif
	// patch the function pointer of the call sequence
	Bit64u addr=(Bit64u)fct_ptr;
	p[0]=A64_MOVZ_X(A64_SCRATCH_A,(Bit32u)(addr&0xffffu),0);
	p[1]=A64_MOVK_X(A64_SCRATCH_A,(Bit32u)((addr>>16)&0xffffu),1);
	p[2]=A64_MOVK_X(A64_SCRATCH_A,(Bit32u)((addr>>32)&0xffffu),2);
	p[3]=A64_MOVK_X(A64_SCRATCH_A,(Bit32u)((addr>>48)&0xffffu),3);
}
#endif

// make freshly generated code visible to the instruction fetch unit
#if defined(__APPLE__)
#include <libkern/OSCacheControl.h>
static void cache_block_closing(Bit8u* block_start,Bitu block_size) {
	sys_icache_invalidate(block_start,block_size);
	DRC_JIT_WRITE_END();		// back to execute mode (no-op unless MAP_JIT W^X is active)
}
#else
static void cache_block_closing(Bit8u* block_start,Bitu block_size) {
	__builtin___clear_cache((char*)block_start,(char*)(block_start+block_size));
}
#endif

static void cache_block_before_close(void) { }
